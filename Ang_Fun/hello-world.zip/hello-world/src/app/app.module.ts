import { CourseComponent } from './courses.component';
import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';
import { Course1Component } from './course1/course1.component';
import { CoursesServie } from './courses.service';


@NgModule({
  declarations: [
    AppComponent, CourseComponent, Course1Component
  ],
  imports: [
    BrowserModule
  ],
  providers: [CoursesServie],
  bootstrap: [AppComponent]
})
export class AppModule { }
