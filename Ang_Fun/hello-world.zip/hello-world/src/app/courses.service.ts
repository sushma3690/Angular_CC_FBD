export class CoursesServie{

    getCourses(){
        return ["c1","c2","c3"];
    }

}