import { Component } from '@angular/core';
import { CoursesServie } from './courses.service';

@Component({

    selector:'courses',
    //template:'<h1>Title:: {{title}}</h1> <h2>Title2:: {{getTitle()}}</h2>'
    template:`<h1>Title:: {{title}}</h1> <h2>Title2:: {{getTitle()}}</h2>
    
    <ul>
    <li *ngFor="let course of  courses">
    {{course}}
    </li>
    </ul>
`
  
})
export class CourseComponent{
    title="List of Courses";
  //  courses=["c1","c2","c3"]; //http-> tightly coupled and same http has to be repeated; hence service
    courses;
   /*  constructor(){
        let service = new CoursesServie(); //tight copuplig
        this.courses = service.getCourses();
    } */
    constructor(service:CoursesServie){
        this.courses = service.getCourses();
    }
    getTitle(){
        return this.title;
    }

}